#pragma once

#include "Physics2D.h"
#include "Render2D.h"

namespace Game2D
{
    class Engine
    {
    public:
        Physics2D::System physicsWorld;
        Render2D::System renderWorld;      
    };
};

