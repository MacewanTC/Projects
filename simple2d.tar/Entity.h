#pragma once 

#include <SDL2/SDL.h>
#include <Box2D/Box2D.h>

#include "Render2D.h"

class Entity
{
public:

    b2Body *physiable;
    Render2D::Model *renderable;   
};

