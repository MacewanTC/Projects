#pragma once

#include <SDL2/SDL.h>

#include "System.h"

namespace Render2D 
{
    class Model 
    {
    public:
            int loadTexture();
    
    };

    class System
    {
    public:
        
    
    };
};

