#pragma once

#include <Box2D/Box2D.h>

#include "System.h"

namespace Physics2D
{

    class System
    {
    public:   
    
    };


};
